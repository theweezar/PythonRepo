import pyshark
import csv
import os

def show_interface():
    print("Current Interface.")
    os.system("netsh interface show interface")

def main():
    show_interface()
    interface = input('Select interface: ')
    count = input('How many packets to be captured: ')
    try: 
        capture = pyshark.LiveCapture(
            interface=interface,
            output_file="output.pcap"
        )
        for packet in capture.sniff_continuously(packet_count=int(count)):
            print('Just arrived:', packet)
    except:
        print("Input wrong data")

if __name__ == "__main__":
    main()