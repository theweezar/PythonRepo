import pyshark
import csv
import os

def main():
    cap = pyshark.FileCapture(f'output.pcap', only_summaries=True)
    cap.set_debug()
    csv_file = open("pcap.csv", "w+")
    try:
        spamwriter = csv.writer(csv_file)
        for pkt in cap:
            pkt_list = str(pkt).split(" ")
            spamwriter.writerow(pkt_list)
    except:
        print("EOF")

    cap.close()

if __name__ == "__main__":
    main()